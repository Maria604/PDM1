import React from 'react';
import { Text } from 'react-native';
function App() {
return <Text>EU AMO AGORITMOS</Text>;
  
}
export default App; 




